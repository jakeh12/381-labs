# Single-Cycle MIPS Processor

## CPRE 381 - Project B

### Jakub Hladik, Dane Larson

Instruction Set:
https://docs.google.com/a/iastate.edu/spreadsheets/d/1mXHmbsyRXv4KM3Injx0UrEQ9bmWfEp_A0qK1ypJ2Isc/edit?usp=sharing

Report:
https://docs.google.com/a/iastate.edu/document/d/16btQY3bSWAu7nnCcnYKk19mj47fAf_z0XikZMqEuLJc/edit?usp=sharing

Detailed MIPS ISA encoding: http://www.mrc.uidaho.edu/mrc/people/jff/digital/MIPSir.html

![MIPS Datapath](https://s10.postimg.org/5f222am1l/single_cycle_mips.png)